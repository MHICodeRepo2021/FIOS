﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services;
using Microsoft.SharePoint;

namespace Mizuho.UploadFileLockDown
{
    [WebService(Namespace = "http://tempuri.org/")]
    public class Service : WebService
    {
        [WebMethod]
        public string UploadFileAndLockDown(  byte[] fileToUpload,   string fileName,  string libraryName,  string permissionToGrant,
  string usersToGetPermissions)
        {
            try
            {
                Guid id1 = SPContext.Current.Site.ID;
                Guid id2 = SPContext.Current.Web.ID;
                using (SPSite spSite = new SPSite(id1))
                {
                    using (SPWeb spWeb = spSite.OpenWeb(id2))
                    {
                        SPListItem spListItem = spWeb.Lists[libraryName].RootFolder.Files.Add(fileName, fileToUpload, true).Item;
                        if (spListItem.HasUniqueRoleAssignments)
                            spListItem.ResetRoleInheritance();
                        spListItem.BreakRoleInheritance(false);
                        SPRoleDefinition roleDefinition = spWeb.RoleDefinitions[permissionToGrant];
                        string str1 = usersToGetPermissions;
                        char[] chArray = new char[1] { ';' };
                        foreach (string str2 in str1.Split(chArray))
                        {
                            SPRoleAssignment spRoleAssignment = new SPRoleAssignment((SPPrincipal)spWeb.EnsureUser(str2));
                            spRoleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                            spListItem.RoleAssignments.Add(spRoleAssignment);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return string.Format("Error uploading file: {0}", (object)ex.Message);
            }
            return "Success";
        }

        [WebMethod]
        public string GetWebSiteNameTest()
        {
            var id1 = SPContext.Current.Web;

            return id1.Title;
        }

    }
}
